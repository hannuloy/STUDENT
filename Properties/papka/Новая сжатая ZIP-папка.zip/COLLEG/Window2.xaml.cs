﻿using COLLEG.BD;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace COLLEG
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
            GRID.ItemsSource = colledgEntities.GetContext().студент.ToList();
        }
    
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var removing = GRID.SelectedItems.Cast<студент>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие{removing.Count()}элементов ", "внимание" ,MessageBoxButton.YesNo,MessageBoxImage.Question) == MessageBoxResult.Yes)
            {


                try
                {
                    colledgEntities.GetContext().студент.RemoveRange(removing);
                    colledgEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");

                    GRID.ItemsSource = colledgEntities.GetContext().студент.ToList();


                }
                catch(Exception ex)
                {

                    MessageBox.Show(ex.Message.ToString());

                }


            }
        }
       

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
        private void timerTick(object sender, EventArgs e)
        {
            BUTTON.Visibility = Visibility.Hidden;
        }

        private void BUTTON_Click_1(object sender, RoutedEventArgs e)
        {
            var CurrentUser = user.polzovatel.пользователь.FirstOrDefault(u => u.логин == LOG.Text && u.пароль == password.Text && u.почта == POCHTA.Text);
            if (CurrentUser != null)
            {
                tbMain.IsEnabled = true;  // разблокируем tabItem
                tcMain.SelectedItem = tbMain;  // переключаемся к разблокированному tabItem
                tbAuto.IsEnabled = false;  // блокируем прошлый tabItem
            }
            else
            {
                MessageBox.Show("Такого пользователя нету");
            }

                if (LOG.Text == null || password.Text == null || POCHTA.Text == null)
                {
                  
                    MessageBox.Show("Вы не ввели данные!");
                   


                }

           



        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

            var checkBox = sender as CheckBox;
            if (checkBox.IsChecked.Value)
            {
                password.Text = pd.Password; // скопируем в TextBox из PasswordBox
                pd.Visibility = Visibility.Visible; // TextBox - отобразить
               pd.Visibility = Visibility.Hidden; // PasswordBox - скрыть
            }
            else
            {
                pd.Password = password.Text; // скопируем в PasswordBox из TextBox 
                password.Visibility = Visibility.Visible; // TextBox - скрыть
                pd.Visibility = Visibility.Hidden; // PasswordBox - отобразить
            }
        }

        private void POKASAT_Click(object sender, RoutedEventArgs e)
        {
            var passrod = checkbox.IsChecked.Value ? password.Text : pd.Password;
            MessageBox.Show(passrod);
        }
    } 
    }
    

