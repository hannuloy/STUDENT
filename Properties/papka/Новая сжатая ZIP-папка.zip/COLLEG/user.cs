﻿using COLLEG.BD;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COLLEG
{
    public static class user
    {
      public static  colledgEntities polzovatel = new colledgEntities(); 
    }
}
